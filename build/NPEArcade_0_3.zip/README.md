# ModJam

Arcade Mod - by NPException

This little arcade mod contains 2 items.
An arcade machine and an arcade seat.

You place the machine down, and then the seat in front of it,
just sit down, and press space :)

Left and right movement keys for controlls.


if you hit a truck, you will get an (atm. intentional) error screen.
Just whack the arcade machine while sitting on the seat to reset it.


In the future, users will be able to put there own games in by simply throwing them in a specified folder.